/* 节奏小奶蛙 - 道具矢量绘制（手持道具 + 关卡物件），原点=握持点 */
(function () {
  const P = RF.props = {};
  const U = RF.util;
  P.draw = function (ctx, name, s, ang) {
    const fn = P[name];
    if (!fn) return;
    ctx.save();
    ctx.rotate(ang || 0);
    fn(ctx, s);
    ctx.restore();
  };

  P.basketball = (ctx, s) => {
    ctx.fillStyle = '#F57C00'; U.circle(ctx, 0, 0, 15 * s); ctx.fill();
    ctx.strokeStyle = '#7a3c00'; ctx.lineWidth = 1.6 * s;
    U.circle(ctx, 0, 0, 15 * s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-15 * s, 0); ctx.lineTo(15 * s, 0);
    ctx.moveTo(0, -15 * s); ctx.lineTo(0, 15 * s); ctx.stroke();
    ctx.beginPath(); ctx.arc(-20 * s, 0, 14 * s, -0.6, 0.6); ctx.stroke();
    ctx.beginPath(); ctx.arc(20 * s, 0, 14 * s, Math.PI - 0.6, Math.PI + 0.6); ctx.stroke();
  };
  P.football = (ctx, s) => {
    ctx.fillStyle = '#fff'; U.circle(ctx, 0, 0, 15 * s); ctx.fill();
    ctx.strokeStyle = '#37474F'; ctx.lineWidth = 1.4 * s; U.circle(ctx, 0, 0, 15 * s); ctx.stroke();
    ctx.fillStyle = '#37474F';
    U.circle(ctx, 0, 0, 5 * s); ctx.fill();
    for (let i = 0; i < 5; i++) {
      const a = i / 5 * U.TAU - Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 5 * s, Math.sin(a) * 5 * s);
      ctx.lineTo(Math.cos(a) * 13 * s, Math.sin(a) * 13 * s);
      ctx.stroke();
    }
  };
  P.volleyball = (ctx, s) => {
    ctx.fillStyle = '#FFF9C4'; U.circle(ctx, 0, 0, 14 * s); ctx.fill();
    ctx.strokeStyle = '#F9A825'; ctx.lineWidth = 2 * s; U.circle(ctx, 0, 0, 14 * s); ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, -14 * s, 16 * s, 0.5, Math.PI - 0.5); ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 14 * s, 16 * s, Math.PI + 0.5, U.TAU - 0.5); ctx.stroke();
  };
  P.tennisball = (ctx, s) => {
    ctx.fillStyle = '#D4E157'; U.circle(ctx, 0, 0, 11 * s); ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.8 * s;
    ctx.beginPath(); ctx.arc(-11 * s, 0, 10 * s, -0.9, 0.9); ctx.stroke();
    ctx.beginPath(); ctx.arc(11 * s, 0, 10 * s, Math.PI - 0.9, Math.PI + 0.9); ctx.stroke();
  };
  P.shuttle = (ctx, s) => {   // 羽毛球
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(0, 6 * s); ctx.lineTo(-8 * s, -14 * s); ctx.lineTo(8 * s, -14 * s); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#B0BEC5'; ctx.lineWidth = 1.2 * s; ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-4 * s, -4 * s); ctx.lineTo(4 * s, -4 * s); ctx.stroke();
    ctx.fillStyle = '#EF5350'; U.circle(ctx, 0, 8 * s, 5.5 * s); ctx.fill();
  };
  P.jianzi = (ctx, s) => {    // 毽子
    ctx.fillStyle = '#F06292';
    for (let i = -2; i <= 2; i++) {
      ctx.save(); ctx.rotate(i * 0.35);
      U.ell(ctx, 0, -10 * s, 3 * s, 10 * s); ctx.fill();
      ctx.restore();
    }
    ctx.fillStyle = '#8D6E63'; U.circle(ctx, 0, 3 * s, 5 * s); ctx.fill();
    ctx.fillStyle = '#FFD34D'; U.circle(ctx, 0, 3 * s, 3 * s); ctx.fill();
  };
  P.dart = (ctx, s) => {      // 飞镖（尖朝上=前进方向）
    ctx.fillStyle = '#90A4AE';
    ctx.beginPath(); ctx.moveTo(0, -16 * s); ctx.lineTo(-3 * s, -6 * s); ctx.lineTo(3 * s, -6 * s); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#EF5350'; U.roundRect(ctx, -2.5 * s, -6 * s, 5 * s, 14 * s, 2 * s); ctx.fill();
    ctx.fillStyle = '#42A5F5';
    ctx.beginPath(); ctx.moveTo(-2.5 * s, 8 * s); ctx.lineTo(-8 * s, 16 * s); ctx.lineTo(-2.5 * s, 13 * s); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(2.5 * s, 8 * s); ctx.lineTo(8 * s, 16 * s); ctx.lineTo(2.5 * s, 13 * s); ctx.closePath(); ctx.fill();
  };
  P.frisbee = (ctx, s) => {
    ctx.fillStyle = '#4FC3F7'; U.ell(ctx, 0, 0, 16 * s, 7 * s); ctx.fill();
    ctx.fillStyle = '#81D4FA'; U.ell(ctx, 0, -2 * s, 11 * s, 4.5 * s); ctx.fill();
    ctx.strokeStyle = '#0288D1'; ctx.lineWidth = 1.2 * s; U.ell(ctx, 0, 0, 16 * s, 7 * s); ctx.stroke();
  };
  /* 球拍类：握持点在手柄末端 */
  P.badminton = (ctx, s) => {
    ctx.strokeStyle = '#5C6BC0'; ctx.lineWidth = 3.4 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -18 * s); ctx.stroke();
    ctx.lineWidth = 2.6 * s;
    U.ell(ctx, 0, -32 * s, 10 * s, 14 * s); ctx.stroke();
    ctx.lineWidth = 0.8 * s; ctx.strokeStyle = 'rgba(92,107,192,0.7)';
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath(); ctx.moveTo(i * 4 * s, -44 * s); ctx.lineTo(i * 4 * s, -20 * s); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-9 * s, (-32 + i * 5) * s); ctx.lineTo(9 * s, (-32 + i * 5) * s); ctx.stroke();
    }
  };
  P.ttball = (ctx, s) => {    // 乒乓球
    ctx.fillStyle = '#FF9800'; U.circle(ctx, 0, 0, 8 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; U.circle(ctx, -2.5 * s, -2.5 * s, 2.6 * s); ctx.fill();
  };
  P.ttpaddle = (ctx, s) => {   // 乒乓球拍
    ctx.strokeStyle = '#8D6E63'; ctx.lineWidth = 4 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -10 * s); ctx.stroke();
    ctx.fillStyle = '#E53935'; U.ell(ctx, 0, -22 * s, 12 * s, 13 * s); ctx.fill();
    ctx.strokeStyle = '#B71C1C'; ctx.lineWidth = 1.4 * s; U.ell(ctx, 0, -22 * s, 12 * s, 13 * s); ctx.stroke();
  };
  P.tennis = (ctx, s) => {
    ctx.strokeStyle = '#26A69A'; ctx.lineWidth = 3.6 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -16 * s); ctx.stroke();
    ctx.lineWidth = 2.8 * s;
    U.ell(ctx, 0, -30 * s, 11 * s, 14 * s); ctx.stroke();
    ctx.lineWidth = 0.8 * s; ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath(); ctx.moveTo(i * 4 * s, -42 * s); ctx.lineTo(i * 4 * s, -18 * s); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-10 * s, (-30 + i * 5) * s); ctx.lineTo(10 * s, (-30 + i * 5) * s); ctx.stroke();
    }
  };
  P.toygun = (ctx, s) => {    // 玩具枪（打飞盘）
    ctx.fillStyle = '#FF7043'; U.roundRect(ctx, -4 * s, -20 * s, 9 * s, 22 * s, 3 * s); ctx.fill();
    ctx.fillStyle = '#FFAB91'; U.roundRect(ctx, -4 * s, -24 * s, 20 * s, 7 * s, 3 * s); ctx.fill();
    ctx.fillStyle = '#42A5F5'; U.circle(ctx, 14 * s, -20 * s, 3.4 * s); ctx.fill();
  };
  P.wheel = (ctx, s) => {     // 方向盘
    ctx.strokeStyle = '#37474F'; ctx.lineWidth = 4 * s;
    U.circle(ctx, 0, -14 * s, 14 * s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-14 * s, -14 * s); ctx.lineTo(14 * s, -14 * s);
    ctx.moveTo(0, -14 * s); ctx.lineTo(0, 0); ctx.stroke();
    ctx.fillStyle = '#EF5350'; U.circle(ctx, 0, -14 * s, 4 * s); ctx.fill();
  };
  P.broom = (ctx, s) => {
    ctx.strokeStyle = '#8D6E63'; ctx.lineWidth = 3.4 * s;
    ctx.beginPath(); ctx.moveTo(0, 4 * s); ctx.lineTo(0, -30 * s); ctx.stroke();
    ctx.fillStyle = '#FFB300'; U.roundRect(ctx, -8 * s, 2 * s, 16 * s, 10 * s, 3 * s); ctx.fill();
  };
  /* ---- 生活类道具 ---- */
  P.flyswat = (ctx, s) => {
    ctx.strokeStyle = '#EF5350'; ctx.lineWidth = 3 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -20 * s); ctx.stroke();
    ctx.fillStyle = 'rgba(239,83,80,0.85)';
    U.roundRect(ctx, -9 * s, -38 * s, 18 * s, 18 * s, 4 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) U.circle(ctx, (-5 + i * 5) * s, (-34 + j * 5) * s, 1.4 * s), ctx.fill();
  };
  P.wrench = (ctx, s) => {
    ctx.strokeStyle = '#78909C'; ctx.lineWidth = 5 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 2 * s); ctx.lineTo(0, -22 * s); ctx.stroke();
    ctx.lineWidth = 4 * s;
    ctx.beginPath(); ctx.arc(0, -26 * s, 7 * s, 0.6, U.TAU - 0.6); ctx.stroke();
  };
  P.hanger = (ctx, s) => {
    ctx.strokeStyle = '#546E7A'; ctx.lineWidth = 2.4 * s;
    ctx.beginPath(); ctx.arc(0, -30 * s, 5 * s, Math.PI, 0); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, -35 * s); ctx.lineTo(0, -28 * s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, -28 * s); ctx.lineTo(-16 * s, -18 * s); ctx.lineTo(16 * s, -18 * s); ctx.closePath(); ctx.stroke();
  };
  P.shirt = (ctx, s) => {
    ctx.fillStyle = '#81D4FA';
    ctx.beginPath();
    ctx.moveTo(-8 * s, -26 * s); ctx.lineTo(-16 * s, -20 * s); ctx.lineTo(-12 * s, -14 * s); ctx.lineTo(-9 * s, -17 * s);
    ctx.lineTo(-9 * s, 2 * s); ctx.lineTo(9 * s, 2 * s); ctx.lineTo(9 * s, -17 * s); ctx.lineTo(12 * s, -14 * s);
    ctx.lineTo(16 * s, -20 * s); ctx.lineTo(8 * s, -26 * s); ctx.closePath(); ctx.fill();
  };
  P.bowl = (ctx, s) => {
    ctx.fillStyle = '#FFFDE7';
    ctx.beginPath(); ctx.arc(0, -6 * s, 14 * s, 0, Math.PI); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#E0C060'; ctx.lineWidth = 1.6 * s; ctx.stroke();
    ctx.beginPath(); ctx.ellipse(0, -6 * s, 14 * s, 4 * s, 0, 0, U.TAU); ctx.stroke();
  };
  P.sponge = (ctx, s) => {
    ctx.fillStyle = '#FFF176'; U.roundRect(ctx, -10 * s, -16 * s, 20 * s, 14 * s, 4 * s); ctx.fill();
    ctx.fillStyle = 'rgba(240,180,40,0.6)';
    U.circle(ctx, -4 * s, -11 * s, 2 * s); ctx.fill();
    U.circle(ctx, 4 * s, -8 * s, 1.6 * s); ctx.fill();
  };
  P.basket = (ctx, s) => {
    ctx.fillStyle = '#A1887F';
    ctx.beginPath(); ctx.moveTo(-16 * s, -14 * s); ctx.lineTo(16 * s, -14 * s); ctx.lineTo(11 * s, 2 * s); ctx.lineTo(-11 * s, 2 * s); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#8D6E63'; ctx.lineWidth = 1.4 * s;
    ctx.beginPath(); ctx.moveTo(-14 * s, -8 * s); ctx.lineTo(14 * s, -8 * s); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, -14 * s, 12 * s, Math.PI, 0); ctx.stroke();
  };
  P.can = (ctx, s) => {   // 浇水壶
    ctx.fillStyle = '#4FC3F7'; U.roundRect(ctx, -9 * s, -18 * s, 18 * s, 16 * s, 4 * s); ctx.fill();
    ctx.strokeStyle = '#4FC3F7'; ctx.lineWidth = 3 * s;
    ctx.beginPath(); ctx.moveTo(9 * s, -14 * s); ctx.lineTo(18 * s, -22 * s); ctx.stroke();
    ctx.beginPath(); ctx.arc(-9 * s, -12 * s, 6 * s, Math.PI * 0.5, Math.PI * 1.5); ctx.stroke();
  };
  P.parcel = (ctx, s) => {
    ctx.fillStyle = '#C8A165'; U.roundRect(ctx, -13 * s, -22 * s, 26 * s, 20 * s, 3 * s); ctx.fill();
    ctx.fillStyle = '#FFF3D6'; ctx.fillRect(-2.5 * s, -22 * s, 5 * s, 20 * s);
    ctx.strokeStyle = '#A87F43'; ctx.lineWidth = 1.4 * s; U.roundRect(ctx, -13 * s, -22 * s, 26 * s, 20 * s, 3 * s); ctx.stroke();
  };
  P.carrot = (ctx, s) => {
    ctx.fillStyle = '#FB8C00';
    ctx.beginPath(); ctx.moveTo(0, 6 * s); ctx.lineTo(-6 * s, -12 * s); ctx.lineTo(6 * s, -12 * s); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#66BB6A';
    U.ell(ctx, -4 * s, -15 * s, 3 * s, 6 * s, -0.4); ctx.fill();
    U.ell(ctx, 4 * s, -15 * s, 3 * s, 6 * s, 0.4); ctx.fill();
  };
  P.cabbage = (ctx, s) => {
    ctx.fillStyle = '#AED581'; U.circle(ctx, 0, -8 * s, 11 * s); ctx.fill();
    ctx.fillStyle = '#7CB342';
    ctx.beginPath(); ctx.arc(0, -8 * s, 11 * s, Math.PI * 0.9, Math.PI * 2.1); ctx.fill();
    ctx.strokeStyle = '#558B2F'; ctx.lineWidth = 1.2 * s;
    ctx.beginPath(); ctx.arc(0, -8 * s, 6 * s, 0.4, 2.6); ctx.stroke();
  };
  P.rotten = (ctx, s) => {
    ctx.fillStyle = '#8D6E63'; U.ell(ctx, 0, -8 * s, 11 * s, 9 * s); ctx.fill();
    ctx.fillStyle = '#6D4C41'; U.ell(ctx, 4 * s, -5 * s, 5 * s, 4 * s); ctx.fill();
    ctx.fillStyle = '#37474F';
    U.circle(ctx, -6 * s, -20 * s, 1.8 * s); ctx.fill();
    U.circle(ctx, 5 * s, -22 * s, 1.8 * s); ctx.fill();
  };
  /* ---- 乐器 ---- */
  P.guitar = (ctx, s) => {
    ctx.fillStyle = '#8D6E63';
    U.circle(ctx, 0, -8 * s, 10 * s); ctx.fill();
    U.circle(ctx, 0, -22 * s, 7 * s); ctx.fill();
    ctx.strokeStyle = '#5D4037'; ctx.lineWidth = 3 * s;
    ctx.beginPath(); ctx.moveTo(0, -28 * s); ctx.lineTo(0, -44 * s); ctx.stroke();
    ctx.strokeStyle = '#FFF9C4'; ctx.lineWidth = 0.8 * s;
    ctx.beginPath(); ctx.moveTo(0, -4 * s); ctx.lineTo(0, -44 * s); ctx.stroke();
  };
  P.violin = (ctx, s) => {
    ctx.fillStyle = '#A1887F';
    U.ell(ctx, 0, -10 * s, 8 * s, 12 * s); ctx.fill();
    ctx.strokeStyle = '#5D4037'; ctx.lineWidth = 2.4 * s;
    ctx.beginPath(); ctx.moveTo(0, -20 * s); ctx.lineTo(6 * s, -40 * s); ctx.stroke();
    ctx.strokeStyle = '#FFF9C4'; ctx.lineWidth = 0.8 * s;
    ctx.beginPath(); ctx.moveTo(-2 * s, -4 * s); ctx.lineTo(4 * s, -38 * s); ctx.stroke();
  };
  P.flute = (ctx, s) => {
    ctx.strokeStyle = '#FFD34D'; ctx.lineWidth = 5 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-16 * s, -10 * s); ctx.lineTo(16 * s, -14 * s); ctx.stroke();
    ctx.fillStyle = '#5D4037';
    for (let i = 0; i < 4; i++) U.circle(ctx, (-8 + i * 6) * s, (-11 - i * 0.8) * s, 1.4 * s), ctx.fill();
  };
  P.mallet = (ctx, s) => {
    ctx.strokeStyle = '#8D6E63'; ctx.lineWidth = 3 * s;
    ctx.beginPath(); ctx.moveTo(0, 2 * s); ctx.lineTo(0, -24 * s); ctx.stroke();
    ctx.fillStyle = '#B0BEC5'; U.circle(ctx, 0, -28 * s, 6 * s); ctx.fill();
  };
  P.sticks = (ctx, s) => {
    ctx.strokeStyle = '#D7A86E'; ctx.lineWidth = 3 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-4 * s, 2 * s); ctx.lineTo(-10 * s, -26 * s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(4 * s, 2 * s); ctx.lineTo(10 * s, -26 * s); ctx.stroke();
  };
  P.trumpet = (ctx, s) => {
    ctx.strokeStyle = '#FFD34D'; ctx.lineWidth = 4 * s;
    ctx.beginPath(); ctx.moveTo(-12 * s, -12 * s); ctx.lineTo(12 * s, -12 * s); ctx.stroke();
    ctx.fillStyle = '#FFD34D';
    ctx.beginPath(); ctx.moveTo(12 * s, -12 * s); ctx.lineTo(20 * s, -18 * s); ctx.lineTo(20 * s, -6 * s); ctx.closePath(); ctx.fill();
    for (let i = 0; i < 3; i++) { U.circle(ctx, (-6 + i * 6) * s, -16 * s, 2 * s); ctx.fill(); }
  };
  P.erhu = (ctx, s) => {
    ctx.fillStyle = '#8D6E63'; U.roundRect(ctx, -6 * s, -12 * s, 12 * s, 14 * s, 3 * s); ctx.fill();
    ctx.strokeStyle = '#5D4037'; ctx.lineWidth = 2.4 * s;
    ctx.beginPath(); ctx.moveTo(0, -12 * s); ctx.lineTo(0, -40 * s); ctx.stroke();
    ctx.strokeStyle = '#FFF9C4'; ctx.lineWidth = 0.8 * s;
    ctx.beginPath(); ctx.moveTo(0, -2 * s); ctx.lineTo(0, -40 * s); ctx.stroke();
  };
  P.harmonica = (ctx, s) => {
    ctx.fillStyle = '#B0BEC5'; U.roundRect(ctx, -14 * s, -14 * s, 28 * s, 8 * s, 3 * s); ctx.fill();
    ctx.fillStyle = '#546E7A';
    for (let i = 0; i < 6; i++) U.circle(ctx, (-10 + i * 4) * s, -10 * s, 1.2 * s), ctx.fill();
  };
  P.plane = (ctx, s) => {   // 纸飞机
    ctx.fillStyle = '#FFFDF4';
    ctx.beginPath(); ctx.moveTo(14 * s, 0); ctx.lineTo(-12 * s, -8 * s); ctx.lineTo(-6 * s, 0); ctx.lineTo(-12 * s, 8 * s); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#B0BEC5'; ctx.lineWidth = 1.2 * s;
    ctx.beginPath(); ctx.moveTo(14 * s, 0); ctx.lineTo(-6 * s, 0); ctx.stroke();
  };
  P.star = (ctx, s) => {
    ctx.fillStyle = '#FFF176';
    ctx.beginPath();
    for (let i = 0; i < 10; i++) { const rr = i % 2 ? 5 * s : 12 * s; const a = i / 10 * U.TAU - Math.PI / 2; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#FBC02D'; ctx.lineWidth = 1.2 * s; ctx.stroke();
  };
  P.mic = (ctx, s) => {
    ctx.fillStyle = '#37474F'; U.circle(ctx, 0, -22 * s, 7 * s); ctx.fill();
    ctx.strokeStyle = '#546E7A'; ctx.lineWidth = 2 * s;
    ctx.beginPath(); ctx.arc(0, -22 * s, 9 * s, 0, Math.PI); ctx.stroke();
    ctx.strokeStyle = '#455A64'; ctx.lineWidth = 3.4 * s;
    ctx.beginPath(); ctx.moveTo(0, -14 * s); ctx.lineTo(0, 2 * s); ctx.stroke();
  };
  /* ---- 办公/生活物件 ---- */
  P.phone = (ctx, s) => {
    /* 手机：小尺寸，金属边框+全面屏+应用图标 */
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.18)'; U.ell(ctx, 1 * s, 10 * s, 10 * s, 3 * s); ctx.fill();
    const g = ctx.createLinearGradient(-8 * s, -20 * s, 8 * s, 8 * s);
    g.addColorStop(0, '#455A64'); g.addColorStop(0.5, '#263238'); g.addColorStop(1, '#37474F');
    ctx.fillStyle = g; U.roundRect(ctx, -8 * s, -20 * s, 16 * s, 28 * s, 3.5 * s); ctx.fill();
    const sg = ctx.createLinearGradient(0, -18 * s, 0, 6 * s);
    sg.addColorStop(0, '#4FC3F7'); sg.addColorStop(1, '#1565C0');
    ctx.fillStyle = sg; U.roundRect(ctx, -6.6 * s, -18.4 * s, 13.2 * s, 24.4 * s, 2.2 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    for (let r2 = 0; r2 < 3; r2++) for (let c = 0; c < 3; c++) { U.roundRect(ctx, (-5 + c * 3.6) * s, (-16 + r2 * 4.4) * s, 2.6 * s, 2.6 * s, 0.8 * s); ctx.fill(); }
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; U.roundRect(ctx, -2.5 * s, 4.6 * s, 5 * s, 1 * s, 0.5 * s); ctx.fill();
    ctx.fillStyle = '#111'; U.circle(ctx, 0, -19.2 * s, 0.8 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath(); ctx.moveTo(-6.6 * s, -18.4 * s); ctx.lineTo(-1 * s, -18.4 * s); ctx.lineTo(-6.6 * s, -6 * s); ctx.closePath(); ctx.fill();
    ctx.restore();
  };
  P.laptop = (ctx, s) => {
    /* 笔电：大尺寸，开合夹角+键盘网格+触控板 */
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.2)'; U.ell(ctx, 0, 6 * s, 22 * s, 4 * s); ctx.fill();
    const bg = ctx.createLinearGradient(0, -26 * s, 0, -2 * s);
    bg.addColorStop(0, '#37474F'); bg.addColorStop(1, '#263238');
    ctx.fillStyle = bg; U.roundRect(ctx, -17 * s, -26 * s, 34 * s, 24 * s, 2.5 * s); ctx.fill();
    const sc2 = ctx.createLinearGradient(-15 * s, -24 * s, 15 * s, -4 * s);
    sc2.addColorStop(0, '#81D4FA'); sc2.addColorStop(0.6, '#4FC3F7'); sc2.addColorStop(1, '#29B6F6');
    ctx.fillStyle = sc2; U.roundRect(ctx, -15.4 * s, -24.4 * s, 30.8 * s, 20.8 * s, 1.5 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    for (let i = 0; i < 4; i++) { U.roundRect(ctx, -13 * s, (-21 + i * 4) * s, (i % 2 ? 16 : 22) * s, 2 * s, 1 * s); ctx.fill(); }
    ctx.fillStyle = 'rgba(255,255,255,0.9)'; U.circle(ctx, 0, -8 * s, 2.6 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.beginPath(); ctx.moveTo(-15.4 * s, -24.4 * s); ctx.lineTo(-4 * s, -24.4 * s); ctx.lineTo(-15.4 * s, -8 * s); ctx.closePath(); ctx.fill();
    const base = ctx.createLinearGradient(0, -2 * s, 0, 6 * s);
    base.addColorStop(0, '#B0BEC5'); base.addColorStop(1, '#78909C');
    ctx.fillStyle = base;
    ctx.beginPath(); ctx.moveTo(-19 * s, -2 * s); ctx.lineTo(19 * s, -2 * s); ctx.lineTo(22 * s, 5 * s); ctx.lineTo(-22 * s, 5 * s); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#546E7A';
    for (let r2 = 0; r2 < 3; r2++) for (let c = 0; c < 10; c++) { U.roundRect(ctx, (-16 + c * 3.2) * s, (-1 + r2 * 1.9) * s, 2.6 * s, 1.4 * s, 0.5 * s); ctx.fill(); }
    ctx.fillStyle = '#90A4AE'; U.roundRect(ctx, -5 * s, 3.2 * s, 10 * s, 1.6 * s, 0.8 * s); ctx.fill();
    ctx.restore();
  };
  P.tablet = (ctx, s) => {
    /* 平板：中尺寸，横放支架+手写笔迹 */
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.18)'; U.ell(ctx, 1 * s, 12 * s, 15 * s, 3.4 * s); ctx.fill();
    ctx.strokeStyle = '#607D8B'; ctx.lineWidth = 2.4 * s;
    ctx.beginPath(); ctx.moveTo(8 * s, 12 * s); ctx.lineTo(14 * s, 2 * s); ctx.stroke();
    const g = ctx.createLinearGradient(-13 * s, -18 * s, 13 * s, 10 * s);
    g.addColorStop(0, '#455A64'); g.addColorStop(1, '#263238');
    ctx.fillStyle = g; U.roundRect(ctx, -13 * s, -18 * s, 26 * s, 28 * s, 3 * s); ctx.fill();
    const sg = ctx.createLinearGradient(0, -16 * s, 0, 8 * s);
    sg.addColorStop(0, '#FFF9C4'); sg.addColorStop(1, '#FFE082');
    ctx.fillStyle = sg; U.roundRect(ctx, -11.4 * s, -16.4 * s, 22.8 * s, 24.8 * s, 1.8 * s); ctx.fill();
    ctx.strokeStyle = '#EF5350'; ctx.lineWidth = 1.6 * s; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-7 * s, 2 * s); ctx.quadraticCurveTo(-2 * s, -8 * s, 2 * s, -1 * s); ctx.quadraticCurveTo(5 * s, 4 * s, 8 * s, -4 * s); ctx.stroke();
    ctx.strokeStyle = '#42A5F5';
    ctx.beginPath(); ctx.moveTo(-7 * s, 5 * s); ctx.lineTo(6 * s, 5 * s); ctx.stroke();
    ctx.fillStyle = '#111'; U.circle(ctx, 0, -17.2 * s, 0.8 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.beginPath(); ctx.moveTo(-11.4 * s, -16.4 * s); ctx.lineTo(-2 * s, -16.4 * s); ctx.lineTo(-11.4 * s, 0); ctx.closePath(); ctx.fill();
    ctx.restore();
  };
  P.handset = (ctx, s) => {
    /* 座机：底座按键阵+听筒+卷线 */
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.18)'; U.ell(ctx, 1 * s, 8 * s, 16 * s, 3.4 * s); ctx.fill();
    const g = ctx.createLinearGradient(0, -8 * s, 0, 8 * s);
    g.addColorStop(0, '#EF5350'); g.addColorStop(1, '#C62828');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.moveTo(-14 * s, -6 * s); ctx.lineTo(14 * s, -6 * s); ctx.lineTo(11 * s, 8 * s); ctx.lineTo(-11 * s, 8 * s); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#FFFDF4';
    for (let r2 = 0; r2 < 3; r2++) for (let c = 0; c < 3; c++) { U.circle(ctx, (-6 + c * 6) * s, (-2 + r2 * 3.6) * s, 1.5 * s); ctx.fill(); }
    ctx.fillStyle = '#B71C1C';
    U.roundRect(ctx, -15 * s, -13 * s, 30 * s, 7 * s, 3.5 * s); ctx.fill();
    ctx.fillStyle = '#8E1414';
    U.circle(ctx, -12 * s, -9.5 * s, 3.4 * s); ctx.fill();
    U.circle(ctx, 12 * s, -9.5 * s, 3.4 * s); ctx.fill();
    ctx.strokeStyle = '#8E1414'; ctx.lineWidth = 1.4 * s;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) ctx.arc(15 * s + i * 2 * s, 4 * s, 1.6 * s, 0, Math.PI);
    ctx.stroke();
    ctx.restore();
  };
  /* 场景物件 */
  P.hoop = (ctx, s) => {      // 篮框（原点=框中心）
    ctx.strokeStyle = '#ECEFF1'; ctx.lineWidth = 5 * s;
    ctx.beginPath(); ctx.moveTo(26 * s, -34 * s); ctx.lineTo(26 * s, 26 * s); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    U.roundRect(ctx, 14 * s, -40 * s, 24 * s, 34 * s, 3 * s); ctx.fill();
    ctx.strokeStyle = '#EF5350'; ctx.lineWidth = 2 * s;
    U.roundRect(ctx, 18 * s, -26 * s, 15 * s, 12 * s, 2 * s); ctx.stroke();
    ctx.strokeStyle = '#FF7043'; ctx.lineWidth = 4 * s;
    ctx.beginPath(); ctx.moveTo(-20 * s, 0); ctx.lineTo(20 * s, 0); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1.6 * s;
    ctx.beginPath();
    ctx.moveTo(-18 * s, 0); ctx.lineTo(-10 * s, 20 * s); ctx.lineTo(10 * s, 20 * s); ctx.lineTo(18 * s, 0);
    ctx.moveTo(-9 * s, 0); ctx.lineTo(-6 * s, 20 * s);
    ctx.moveTo(9 * s, 0); ctx.lineTo(6 * s, 20 * s);
    ctx.stroke();
  };
  P.flag = (ctx, s, color) => {
    ctx.fillStyle = color || '#EF5350';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(14 * s, 5 * s); ctx.lineTo(0, 10 * s); ctx.closePath(); ctx.fill();
  };
})();
